from setuptools import setup
setup(name='predictsense',
version='0.1',
description='Testing installation of Package',
url='#',
author='Winjit.com',
author_email='predictsense@winjit.com',
license='MIT',
packages=['predictsense'],
zip_safe=False)