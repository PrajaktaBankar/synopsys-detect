#PredictSense toolkit

######Steps to setup and run the toolkit

1) Install python >=3
2) Extract and navigate to the build folder
3) To start the toolkit run shell script using below command:

        sh toolkit-start.sh
        
4) Below are the env variables can be set:

        - TOOLKIT_HOSTNAME: toolkit app IP address
        - TOOLKIT_PORT: port on which toolkit runs
 
How to use:

- You can utilize the below api's to get the predictions with respect to 
each project type, 
- for modelid query param use model folder name present inside models

    ######Project: Predictive Modeling
    
        API Endpoint: /api/prediction?id=modelid&projectType=predictive_modeling

        1) JSON Format 1
            ---------------------
            [
                {
                    "colName":"colValue",
                    "colName":"colValue"
                },
                {
                    "colName":"colValue",
                    "colName":"colValue"
                }
            ]
    
        2) JSON Format 2
            ---------------------
                {
                    "filepath":"Absolute filepath",
                    "fileEncoding":"Appropriate encoding of the file ex:utf-8"
                   
                }

    ######Project: Timeseries

        API Endpoint: /api/prediction?id=modelid&projectType=timeseries&result=json/graph
    
            JSON Format
            ---------------------
                {
                "startDate":"mm/dd/yyyy",
                "endDate": "mm/dd/yyyy"
                }
                
    ###### Project: Clustering
        
        API Endpoint: /api/prediction?id=modelid&projectType=clustering&result=json/graph
        
        1) JSON Format 1
            ---------------------
            [
                {
                    "colName":"colValue",
                    "colName":"colValue"
                },
                {
                    "colName":"colValue",
                    "colName":"colValue"
                }
            ]
        
        2) JSON Format 2
            ---------------------
                {
                    "filepath":"Absolute filepath",
                    "fileEncoding":"Appropriate encoding of the file ex:utf-8"
                }
                
    ###### To get a list of models and their details
        
        Below API will return a list of model IDs and their names.

        GET API: /api/model

        Output JSON format:
        ---------------------

        [
            {
                'id': 'model_id',
                'name': 'model name',
                'algoType': 'algorithm type',
                'createdAt': 'time of creation',
                'depVariable': 'name of the target variable'
                                                                                
            {
                'id': 'model_id',
                'name': 'model name',
                'algoType': 'algorithm type',
                'createdAt': 'time of creation',
                'depVariable': 'name of the target variable'
            }
        ]

    ###### Get details about the model using its ID
        
        Below API will return a JSON object with details related to the model.
        In case of regression/forecasting/clustering, the classNames is null.

        GET API: /api/model/<model_id>

        Output JSON format:
        ---------------------

        {
            "formData": [
                {
                    "featureName": "independent feature name",
                    "dataType": "independent feature type",
                    "data": "placeholder value"
                },
            ],
            "projectType": "project type",
            "algoType": "algorithm type",
            "modelName": "model file name",
            "createdAt": "time of creation",
            "depVariable": "name of the target variable",
            "trainingMetrics": {
                "losses": [
                    {
                        "value": "metric value",
                        "name": "metric name"
                    },
                ]
            },
            "classNames": ['class 1', 'class 2']
        }

Note:
* You can always replace the default server with unicorn, nginx etc.
* Please add security for api