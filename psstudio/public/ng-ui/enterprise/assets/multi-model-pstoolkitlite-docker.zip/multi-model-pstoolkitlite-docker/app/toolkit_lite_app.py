# Created by Atul Singh on March 20, 2021
import pandas as pd
import json
import os
import sys
import warnings
from datetime import datetime
import flask
from flask import Flask, request, jsonify, render_template,send_file
from flask_cors import CORS

try:
    import predictsense
except Exception as e:

    sys.path.append(
        "/usr/local/lib/python3.7/site-packages/predictsense-0.1-py3.7.egg/modules")
    import predictsense

try:
    import modules
except ImportError:
    sys.path.append("../app")

from modules.logger.logger import logger
from modules.utils_lite import model_placeholder_lite as mp
from modules.utils_lite import ps_util_lite

# logger = logging.getLogger('PredictSense Toolkit')
# logging.basicConfig(level=logging.DEBUG)
# logging.basicConfig(level=logging.DEBUG, filename='toolkit_app.log',
# filemode='w')

warnings.filterwarnings(action='ignore', category=DeprecationWarning)

logger.propagate = False
app = Flask(__name__)
CORS(app)
app.config['JSON_SORT_KEYS'] = False
app.config['NLP_PATH'] = os.path.join(os.getcwd(), "textanalysis", "models")

job_config = dict()


@app.route('/')
@app.route('/static/')
def render_ui():
    return render_template('index.html')


@app.route('/api/upload_model', methods=['POST'])
def upload_model():
    """
    Uploads the models zip file

    Parameters
    ------
        No param
    Returns
    ------
    response: dict
        status: str
            success/failed
        message: str
            success message or error message
    Exceptions
    ------
        Raises exception if fails to upload file
    """

    try:
        from werkzeug.utils import secure_filename
        ALLOWED_EXTENSIONS = ('zip', 'gz', 'tgz', 'xz', 'bz2')

        file = request.files['file']
        if file.filename == '':
            return jsonify(
                {
                    "status": "failed",
                    "message": "No file selected for uploading"
                }), 400

        if file and file.filename.rsplit('.', 1)[
            1].lower() in ALLOWED_EXTENSIONS:
            models_path = 'models'
            filename = secure_filename(file.filename)
            os.makedirs(models_path, exist_ok=True)

            file.save(os.path.join(models_path, filename))
            logger.info(
                '********Model is uploaded successfully********')

            # extracting model zip file and updating model config
            mp.extract_file(models_path)

            return jsonify(
                {
                    "status": "success",
                    "message": "Model is uploaded successfully"
                })

        else:
            return jsonify(
                {
                    "status": "failed",
                    "message": "Uploaded file format is not supported"
                }), 400

    except Exception as e:
        logger.exception(f'error at uploading zip file {e}')
        return jsonify(
            {
                "status": "failed",
                "message": "Error at uploading zip file"
            }), 400


@app.route('/api/model', defaults={'id': None}, methods=['GET'])
@app.route('/api/model/<id>', methods=['GET', 'DELETE'])
def model(id):
    """
    Perform operations based on method requested

    Parameters
    ------
        id: str
            Model id/ dir name of model
    Returns
    ------
        Models info based on method requested
    Exceptions
    ------
        Raises exception if fails to perform operation
    """
    if flask.request.method == 'GET':

        try:
            if id is None:
                with open('model_config.json', 'r') as con:
                    config = json.load(con)

                return jsonify(config)
            else:
                with open(f'models/{id}/config.json', 'r') as con:
                    configs = json.load(con)
                metaDataFilePath = configs['metaDataFilePath']

                with open(f'models/{id}/{metaDataFilePath}', 'r') as con:
                    config = json.load(con)

                if 'confusionMatrixFilename' in configs:
                    confusionMatrix = configs['confusionMatrixFilename']
                    with open(f'models/{id}/{confusionMatrix}', 'r') as cm:
                        config['confusionMatrix'] = cm.readline()

                if config['algoType'] == 'classification':
                    if config['isMultilabel'] == True:
                        config['classificationType'] = 'multilabel'
                    else:
                        if len(config['classNames']) == 2:
                            config['classificationType'] = 'binary'
                        else:
                            config['classificationType'] = 'multiclass'
                if config['algoType'] == 'timeseries':
                    if config['algorithm'] == 'Prophet':
                        config['exogVariables'] = []

                return jsonify(config)

        except FileNotFoundError as e:
            logger.exception(
                f' Model {"" if id is None else configs} does not '
                f'exist: {e}')
            return jsonify(
                {
                    "status": "failed",
                    "message": f'{"Model config" if id is None else configs} '
                    f'does not exist'
                }), 400

    elif flask.request.method == 'DELETE':

        try:
            status, message = mp.remove_model(id)
        except Exception as e:
            logger.exception(f"Error at performing retraining: {e}")
            status = 'failed'
            message = str(e)

        if status == 'failed':
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing model: {message}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": message,
                })


@app.route('/api/prediction', methods=['POST'])
def perform_prediction():
    
    """
    Get the JSON data , filepath and file_encoding = 'utf-8'

    Parameters
    ------
        No params are required
    Returns
    ------
    dict
        prediction data in json format
    Exceptions
    ------
        Raises exception if fails to compute prediction and
        returns error message
    """

    prediction_data = None
    if request.args.get('result', "other") != "file_upload":
        prediction_data = request.get_json()
    logger.info('Prediction data: {}'.format(prediction_data))

    project = request.args.get('projectType')
    encoding_codec = request.args.get('fileEncoding')
    id = request.args.get('id')
    models_path = os.path.join('models', id)
    model_config = {}
    if id in model_config:
        config = model_config[id]['config']
        metadata = model_config[id]['metadata']
    else:
        if id in os.listdir('models'):
            try:
                with open(f'{models_path}/config.json', 'r') as con:
                    config = json.load(con)
                    metafile = config['metaDataFilePath']
                # reading metadata
                try:
                    with open(f'{models_path}/{metafile}', 'r',
                              encoding="utf-8") as meta:
                        metadata = json.load(meta)
                except FileNotFoundError as e:
                    logger.exception(
                        f' Model metadata file does not exist: {e}')
                    return jsonify(
                        {
                        "status": "failed",
                        "message": f'Model metadata file does not exist: {id}'
                        }),
            except FileNotFoundError as e:
                logger.exception(
                    f' Model Config file does not exist: {e}')
                return jsonify(
                    {
                        "status": "failed",
                        "message": f'Model Config file does not exist: {id}'
                    }), 400

            model_config[id] = {
                'config': config,
                'metadata': metadata
            }

        else:
            return jsonify(
                {
                    "status": "failed",
                    "message": f'Invalid model Id: {id}'
                }), 400

    prediction_obj = dict(
        logger=logger,
        metadata=metadata,
        config=config,
        project=project,
        id=id,
        encoding_codec=encoding_codec
    )

    if request.args.get('projectType') in ['timeseries', 'clustering']:
        prediction_obj['resultType'] = request.args.get('result')

    try:
        response = ps_util_lite.Utils(logger, prediction_obj).get_prediction(
            prediction_data)
        if request.args.get('result')=="file_upload":

            timestamp = str(int(round(datetime.now().timestamp())))
            data_frame = pd.DataFrame(response)
            csv_name = "predicted_data"+"_"+timestamp+".csv"
            models_path = 'models'
            path = os.path.join(models_path,id,csv_name)
            data_frame.to_csv(path.replace(":", "_"),index=False)
            
            return jsonify({
                "status": "success",
                "message": "Prediction has been completed",
                "results": response[:10],
                "path": path})
        else:
            return jsonify({
                "status": "success",
                "message": "Prediction has been completed",
                "results": response
            })


    except Exception as e:
        logger.exception(f"Error at performing prediction: {e}")
        response = str(e)

    if isinstance(response, str):
        return jsonify(
            {
                "status": "failed",
                "message": f"Error at performing prediction: {response}"
            }), 400


@app.route('/api/prediction/download', methods=['GET'])
def download_prediction():
    """
    Get the JSON data , filepath

    Parameters
    ------
        No params are required
    Returns
    ------
        Download prediction data in csv file
    Exceptions
    ------
        Raises exception if fails to download the file and
        returns error message
    """
    path = request.args.get('path')
    path.replace(":","_")

    try:

        return send_file(path, as_attachment=True)

    except Exception as e:

        logger.exception(f"Error at Downloading prediction file: {e}")
        response = str(e)
        return jsonify({
                        "status": "failed",
                        "message": f"Error at Downloading "\
                                   f" prediction file: {response}"
                        }), 400

if __name__ == '__main__':
    # setting default toolkit host and port
    default_host = '0.0.0.0'
    default_port = 5005

    # fetching host and port from env var if default is not set
    host = os.environ.get('TOOLKIT_HOSTNAME', default_host)
    port = os.environ.get('TOOLKIT_PORT', default_port)
    logger.info(
        f'********Toolkit running on Host={host} and Port={port}********')

    app.run(host=host, port=port, debug=False)
