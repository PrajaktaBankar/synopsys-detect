#!/usr/bin/env bash

echo 'Installing requirements...'
pip install -r requirements.txt

cd app
echo $PWD

python execute_model_script.py

echo 'Installing predictsense package...'
pip install predictsense-5.0.1-cp37-cp37m-linux_x86_64.whl
echo 'Starting toolkit app...'
stdbuf -oL python toolkit_app.py