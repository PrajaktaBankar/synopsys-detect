import multiprocessing
import os
from datetime import date

import pandas as pd
from bson.objectid import ObjectId

from .alert import Alert
from .ps_drift import ComputeDrift
from .ps_retrain import Retrain
from .ps_token import db


class Task:

    def __init__(self, logger):
        self.logger = logger

    def get_task(self, task_id):
        """
            get available task from scheduler

            Parameters
            ------
                task_id: str
                    task id of scheduler task
            Returns
            ------
                list of objects task info

            Exceptions
            ------
                Raises exception if fails to retrieve task info
        """
        task = pd.DataFrame()
        try:
            for cursor in db.scheduler.find(
                    {
                        "task.taskId": task_id
                    },

                    {'task': 1}):
                task = pd.DataFrame(cursor['task'])

            if task.empty:
                return dict()
            else:

                task_type = task.loc[task['taskId'] == task_id,
                                     'taskType'].item()

                if task_type == 'retrain':

                    for cursor in db.retrain.find({
                        "_id": task_id
                    },
                            {
                                'modelId': 1
                            }
                    ):
                        model_id = cursor['modelId']

                elif task_type == 'monitor':
                    for cursor in db.monitor.find({
                        "_id": task_id
                    },
                            {
                                'modelId': 1
                            }
                    ):
                        model_id = cursor['modelId']

                for cursor in db.models.find({
                    "_id": model_id
                },
                        {
                            '_id': 1,
                            'modelName': 1,
                            'algorithm': 1
                        }
                ):
                    cursor['modelId'] = cursor.pop('_id')
                return cursor
        except Exception as e:
            self.logger.exception(f'Error at fetching details {e}')
            return str(e)

    def remove_task(self, task_id):

        """
            remove available task from scheduler

            Parameters
            ------
                task_id: str
                    task id of scheduler task
            Returns
            ------
                list of objects task info

            Exceptions
            ------
                Raises exception if fails to remove task info
        """

        try:
            # removing task id of assigned model
            db.scheduler.find_and_modify({'task.taskId': task_id
                                          },
                                         {'$pull':
                                             {
                                                 "task":
                                                     {
                                                         "taskId": task_id
                                                     }
                                             }
                                         }
                                         )
            self.logger.info(f'Task {task_id} has been removed.')

            # removing job id from retrain if task is deleted
            db.retrain.update({'_id': task_id}, {'$unset': {'jobId': 1}})
            # removing job id from monitor if task is deleted
            db.monitor.update({'_id': task_id}, {'$unset': {'jobId': 1}})

            return {
                'taskId': task_id
            }
        except Exception as e:
            self.logger.exception(f'error at removing task: {e}')
            return str(e)

    def execute_task(self, args=None):

        """
        execute the job with assigned task

        Parameters
        ------
            args: dict
                job_id of job which are scheduled

        Returns
        ------
            success message when task executed

        Exceptions
        ------
            Raises exception if fails to execute task
        """

        task = pd.DataFrame()
        for cursor in db.scheduler.find({'_id': args['job_id']},
                                        {
                                            "_id": 1,
                                            "jobName": 1,
                                            "jobStatus": 1,
                                            "task": 1
                                        }):
            task = pd.DataFrame(cursor['task'])

        if not task.empty:
            monitor_task = task.loc[task.taskType.isin(['monitor']), 'taskId']
            retrain_task = task.loc[task.taskType.isin(['retrain']), 'taskId']

            '''
            The pool distributes the tasks to the available processors using a 
            FIFO scheduling. It maps the input to the different processors 
            and collects the output from all the processors. After the 
            execution of code, it returns the output in form of a list or array
            '''

            try:
                # multiprocessing processes
                if not monitor_task.empty:
                    with multiprocessing.Pool(initializer=None) as pool:
                        pool.starmap(
                            func=self.execute_monitoring,
                            iterable=((task,) for task in
                                      monitor_task.to_list()))
                        pool.close()
                    self.logger.info(f'Multiprocess pool {pool}')
            except Exception as e:
                self.logger.exception('error at monitor execution', e)
                pass

            try:
                if not retrain_task.empty:
                    with multiprocessing.Pool(initializer=None) as pool:
                        pool.starmap(
                            func=self.execute_retraining,
                            iterable=((task,) for task in
                                      retrain_task.to_list()))
                        pool.close()
            except Exception as e:
                self.logger.exception('error at retraining execution', e)
                pass

            self.logger.info('Scheduler task has been executed')

        return 'Task has been executed'

    def execute_monitoring(self, task_id):

        """
        execute the monitoring

        Parameters
        ------
            task_id: str
                task id of monitoring which are scheduled

        Returns
        ------
            success message when monitoring executed

        Exceptions
        ------
            Raises exception if fails to execute monitoring
        """

        drift_obj = dict()
        for cursor in db.monitor.find(
                {
                    '_id': task_id
                },
        ):
            drift_obj['modelId'] = cursor['modelId']

            if 'alertId' in cursor:
                drift_obj['alertId'] = cursor['alertId']
                drift_obj['featuresToMonitor'] = cursor['featuresToMonitor']

                if drift_obj['alertId'] in [None, pd.np.nan]:
                    drift_obj.pop('alertId')

        for cursor in db.models.find(
                {
                    '_id': drift_obj['modelId']
                },
        ):
            model_name = cursor['modelName']

        # for cursor in db.scheduler.find({'_id':cursor['jobId']}):
        #     start_date = pd.to_datetime(cursor['startDate']+ ' '+
        #                                 cursor['startTime'])
        #
        #     end_date = pd.to_datetime(cursor['next_run_time'],
        #                                       unit='s')
        #
        #     time_delta = end_date-start_date
        #     days = time_delta.days

        # Todo: collect data from prediction collection based
        #  on scheduler time span and pass it to incomingData

        # Get the last execution date of the drift report
        last_exec_date = list(db.drift_report.find({
            "modelId": drift_obj['modelId'],
            "executionType": "scheduler"},
            {"createdAt": 1, "_id": 0}).sort([("createdAt", -1)]).limit(1))
        if len(last_exec_date) == 0:
            # If executing for the first time, get the date of
            # last manual drift execution
            last_exec_date = list(db.drift_report.find({
                "modelId": drift_obj['modelId']},
                {"createdAt": 1, "_id": 0}).sort([("createdAt", 1)]).limit(1))

        # Get the prediction data since the last execution time
        if len(last_exec_date) > 0:
            last_exec_date = last_exec_date[0]['createdAt']
            incoming_data = list(db.prediction.find({
                "modelId": drift_obj['modelId'],
                "predictionAt": {
                    "$gte": pd.to_datetime(last_exec_date)}},
                {"predictionData": 1, "_id": 0}))
            incoming_name = "prediction_data_" + str(last_exec_date) + \
                            "_" + str(pd.datetime.now()) + ".pkl"
        else:
            # If it is the first time computing drift, then fetch all the data
            incoming_name = "prediction_data_" + str(
                pd.datetime.now()) + ".pkl"
            incoming_data = list(db.prediction.find({
                "modelId": drift_obj['modelId']}, {
                "predictionData": 1, "_id": 0}))

        if len(incoming_data) == 0:
            # Predictions have never been performed, so no data to compute drift
            report_id = str(ObjectId())
            response = {
                'executionType': 'scheduler',
                'createdAt': pd.datetime.now(),
                'status': 'failed',
                'name': model_name + '_' + str(date.today()),
                'message': 'Data unavailable for computing drift.',
                'modelName': model_name,
                'modelId': drift_obj['modelId'],
            }
            if 'alertId' in drift_obj:
                response['alertId'] = drift_obj['alertId']
            ComputeDrift(self.logger)._ComputeDrift__update_collection(
                report_id=report_id,
                data=response
            )
            response['reportId'] = report_id
        else:
            incoming_data = pd.DataFrame(
                [x['predictionData'] for x in incoming_data])
            # Remove the prediction columns
            prediction_columns = [
                x for x in incoming_data.columns if x.startswith(
                    "prediction_probability_class") or x == 'predicted_value']
            incoming_data.drop(prediction_columns, axis=1, inplace=True)
            # While saving the prediction data to the db, we are replacing
            # the None values with empty strings, we need to replace them back
            for feature in incoming_data.columns:
                incoming_data.loc[incoming_data[
                                      feature].astype(
                    'str').str.len() == 0, feature] = None
            # Save the incoming data
            # creating the directory where prediction file gets copied
            directory = os.path.join('projects', str(drift_obj['modelId']))
            # checking the directory exist or not
            if not os.path.exists(directory):
                os.makedirs(directory)
            incoming_data.to_pickle(os.path.join(
                'projects', drift_obj['modelId'], incoming_name))

            drift_obj['incomingData'] = incoming_name
            drift_obj['driftReportName'] = model_name + '_' + str(
                date.today())
            drift_obj['modelName'] = model_name
            drift_obj['executionType'] = 'scheduler'
            drift_obj['status'] = 'success'

            response = ComputeDrift(self.logger).create_drift_report(
                drift_obj)
        try:
            self.execute_alert(task_type='monitor',
                               task_id=response['reportId'],
                               message=(
                                   response['message']
                                   if 'message' in response
                                   else None)
                               )
        except Exception as e:
            self.logger.exception(f'error at executing alert {e}')
            pass
        return response

    def execute_retraining(self, task_id):

        """
           execute the retraining

           Parameters
           ------
               task_id: str
                   task id of retraining which are scheduled

           Returns
           ------
               success message when retraining executed

           Exceptions
           ------
               Raises exception if fails to execute retraining
        """

        model_id = None
        retraining_obj = dict()

        for cursor in db.retrain.find(
                {
                    '_id': task_id
                },
        ):
            model_id = cursor['modelId']

        if 'alertId' in cursor:
            retraining_obj['alertId'] = cursor['alertId']
        retraining_obj['jobId'] = cursor['jobId']
        retraining_obj['mergeData'] = cursor['mergeData']
        retraining_obj['overwriteModel'] = cursor['overwriteModel']
        retraining_obj['source'] = cursor['source']
        retraining_obj['retrainType'] = cursor['retrainType']
        if cursor['retrainType'] == 'refit':
            retraining_obj['sqlQuery'] = cursor['sqlQuery']
        else:
            retraining_obj['sqlQuery'] = None

        for cursor in db.models.find({'_id': model_id},
                                     {
                                         'projectType': 1,
                                         'modelDir': 1
                                     }):
            pass
        toolkit_obj = dict(
            project=cursor['projectType'],
            id=cursor['modelDir'],
            encoding_codec=cursor.get('fileEncoding', None)
        )

        response = Retrain(self.logger, toolkit_obj, retraining_obj
                           ).retrain_model(dict(
            sqlQuery=retraining_obj['sqlQuery']) if retraining_obj[
            'sqlQuery'] else dict(), 'alertId' in retraining_obj)

        try:
            self.execute_alert(task_type='retrain',
                               task_id=response[0],  # retrain_id
                               model_id=response[1],  # model_id
                               model_name=response[2],  # model_name
                               html_string=response[4]  # html_string
                               )
        except Exception as e:
            self.logger.exception(f'error at executing alert {e}')
            pass

        return response

    def execute_alert(self, task_type='retrain', **kwargs):

        """
        execute the alert

        Parameters
        ------
            task_type: str:
                retrain or monitor
            kwargs: str
                args of an alert

        Returns
        ------
            success message when task executed

        Exceptions
        ------
            Raises exception if fails to execute alert
        """

        if task_type == 'retrain':
            try:
                for cursor in db.retrain.find({'_id': kwargs['task_id']}):

                    if 'alertId' in cursor:
                        alert_obj = Alert(self.logger)
                        alert_config = alert_obj.get_alert(
                            cursor['alertId'])

                        alert_message = alert_obj.get_template(
                            alert_type=alert_config['alertType'],
                            task_type=task_type,
                            model_id=kwargs['model_id'],
                            model_name=kwargs['model_name'],
                            html_string=kwargs['html_string']
                        )

                        alert_obj.send_alert(cursor['alertId'],
                                             alert_config['alertType'],
                                             'retrain',
                                             alert_message
                                             )
                        db.retrain.update(
                            {
                                "_id": kwargs['task_id']
                            },
                            {
                                "$set": {'alertStatus': 'success'}
                            },
                            upsert=True)
                    return 'Alert sent'
            except Exception as e:
                self.logger.exception(f'Error at sending alert: {e}')
                db.retrain.update(
                    {
                        "_id": kwargs['task_id']
                    },
                    {
                        "$set": {'alertStatus': 'failed'}
                    },
                    upsert=True)
                return str(e)

        elif task_type == 'monitor':

            try:
                for cursor in db.drift_report.find({'_id': kwargs['task_id']}):
                    if 'alertId' in cursor:
                        alert_obj = Alert(self.logger)
                        alert_config = alert_obj.get_alert(
                            cursor['alertId'])
                        alert_message = alert_obj.get_template(
                            alert_type=alert_config['alertType'],
                            task_type='drift',
                            report_id=cursor['_id'],
                            model_name=cursor[
                                'modelName'],
                            report_name=cursor[
                                'name'],
                            message=(kwargs[
                                         'message'] if 'message' in kwargs else None)
                        )

                        alert_obj.send_alert(cursor['alertId'],
                                             alert_config['alertType'],
                                             'drift',
                                             alert_message,
                                             status=cursor['status']
                                             )
                        db.drift_report.update(
                            {
                                "_id": kwargs['task_id']
                            },
                            {
                                "$set": {'alertStatus': 'success'}
                            },
                            upsert=True)
                        return 'Alert sent'
            except Exception as e:
                self.logger.exception(f'Error at sending alert: {e}')
                db.drift_report.update(
                    {
                        "_id": kwargs['task_id']
                    },
                    {
                        "$set": {'alertStatus': 'failed'}
                    },
                    upsert=True)
                return str(e)

    def update_task(self, job_id, old_task_id, task_args,
                    request_type='insert'):

        """
        execute the job with assigned task

        Parameters
        ------
            job_id: str
                id of job which are scheduled
            old_task_id: str
                old task id of model
            task_args: dict
                contains taskId and taskType
            request_type: str
                insert or update
        Returns
        ------
            job_config : dictionary
                job config as per below key
                {
                    'job': self.job_config[job_id]['job'],
                    'jobId': job_id,
                    'jobStatus': "inactive"
                }

        Exceptions
        ------
            Raises exception if fails to execute job
        """

        if old_task_id == task_args['taskId'] and request_type == 'insert':

            # removing task from old job id
            db.scheduler.find_and_modify({'task.taskId': old_task_id
                                          },
                                         {'$pull':
                                             {
                                                 "task":
                                                     {
                                                         "taskId": old_task_id
                                                     }
                                             }
                                         }
                                         )

            db.scheduler.update(
                {
                    "_id": job_id
                },
                {
                    "$push": {
                        'task': task_args
                    }
                })

        else:
            # retrain
            db.scheduler.find_and_modify(
                query={
                    "_id": job_id,
                    "task.taskId": old_task_id
                },
                update={
                    "$set":
                        {
                            'task.$.taskId': task_args['taskId'],
                            'task.$.taskType': task_args['taskType']
                        }

                }
            )
        return 'Task has been updated'
