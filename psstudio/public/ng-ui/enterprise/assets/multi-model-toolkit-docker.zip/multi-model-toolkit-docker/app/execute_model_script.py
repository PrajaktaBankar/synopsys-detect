# created by saurabh on Dec 3, 2020

import json
import logging
import os
import time

from modules.utils.ps_token import db

logger = logging.getLogger('Deployed models')
logging.basicConfig(level=logging.DEBUG)


def create_model_config(filename, object_id=None, parent_model_id=None):
    """
        extract model info and write details in models collection

        Parameters
        ------
            filename: str
                downloaded model zip filename
            object_id: str
                id of an object in mongodb collection
            parent_model_id: str
                model id of parent model
        Returns
        ------
            message info
        Exceptions
        ------
            Raises exception if fails to update models info
    """

    # splitting filename eg: project_name + model_name
    model_name = filename.rsplit('-', 1)[0].split('-', 1)[1]
    timestamp = str(int(time.time()))
    final_model_name = model_name + '-' + timestamp

    try:
        with open(f'models/{filename}/config.json', 'r',
                  encoding="utf-8") as f:
            config = json.load(f)
            metafile = config['metaDataFilePath']

        # reading metadata
        with open(f'models/{filename}/{metafile}', 'r',
                  encoding="utf-8") as meta:
            metadata = json.load(meta)

        with open(f'models/{filename}/ui_config.json', 'r',
                  encoding="utf-8") as con:
            ui_config = json.load(con)

        model_info = dict()

        model_info.update(config)
        model_info.update(metadata)

        # ui_config.pop('formData')

        model_info.update(ui_config)

        model_info['parentModelId'] = parent_model_id
        model_info['modelName'] = final_model_name
        model_info['modelDir'] = filename

        if not get_model(filename):

            if object_id is None:
                object_id = model_info['modelId']
                model_info.pop('modelId')

            if get_model(filename) is None:
                update_models_collection(object_id, model_info)

            elif len(get_model(filename)) == 0:
                update_models_collection(object_id, model_info)

            logger.info(f'Updated models info: {filename}')

        return final_model_name

    except FileNotFoundError as e:
        logger.exception(
            f'file does not exist: {e}')
        return str(e)


def get_model(model_dir):
    """
        fetching model from the db

        Parameters
        ------
            model_dir: str
                path of a model

        Returns
        ------
            message info

        Exceptions
        ------
            Raises exception if fails to fetch models info
    """

    try:

        for cursor in db.models.find({"modelDir": model_dir},
                                     {"_id": 1
                                      }):
            cursor['modelId'] = cursor.pop('_id')
            return cursor

    except Exception as e:
        logger.exception(f'error at fetching model info: {e}')
        return str(e)


def update_models_collection(id, data):
    """
        update models info to the db

        Parameters
        ------
            id: str
                id of a model
            data: dict
                data which needs to be updated in db
        Returns
        ------
            message info
        Exceptions
        ------
            Raises exception if fails to update models info
    """

    try:
        db.models.update(
            {
                "_id": id
            },
            {
                "$set": data
            },
            upsert=True)
        return 'Updated models info'
    except Exception as e:
        logger.exception(f'Error at updating collection: {e}')
        return str(e)


if __name__ == '__main__':
    for file in os.listdir('models'):
        create_model_config(file)
