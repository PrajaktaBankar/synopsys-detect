import os
import sys
import warnings
import tempfile
from datetime import datetime


import flask
from bson.objectid import ObjectId
from flask import Flask, request, jsonify, render_template,send_file
from flask_cors import CORS
import pandas as pd
from pathlib import Path
try:
    import predictsense
except Exception as e:

    sys.path.append(
        "/usr/local/lib/python3.7/site-packages/predictsense-0.1-py3.7.egg/modules")
    import predictsense

try:
    import modules
except ImportError:
    sys.path.append("../app")

from modules.logger.logger import logger
from modules.utils import alert
from modules.utils import model_placeholder as mp
from modules.utils import ps_drift
from modules.utils import ps_retrain
from modules.utils import ps_sql
from modules.utils import ps_util
from modules.utils import scheduler
from modules.utils import task
from modules.utils import monitor

# logger = logging.getLogger('PredictSense Toolkit')
# logging.basicConfig(level=logging.DEBUG)
# logging.basicConfig(level=logging.DEBUG, filename='toolkit_app.log',
# filemode='w')

warnings.filterwarnings(action='ignore', category=DeprecationWarning)

logger.propagate = False
app = Flask(__name__)
CORS(app)
app.config['JSON_SORT_KEYS'] = False
app.config['NLP_PATH'] = os.path.join(os.getcwd(), "textanalysis", "models")

job_config = dict()


@app.route('/')
@app.route('/static/')
def render_ui():
    return render_template('index.html')


@app.route('/api/upload_model', methods=['POST'])
def upload_model():
    """
    Uploads the models zip file

    Parameters
    ------
        No param
    Returns
    ------
    response: dict
        status: str
            success/failed
        message: str
            success message or error message
    Exceptions
    ------
        Raises exception if fails to upload file
    """
    logger.info("##########################3333333333333")
    try:
        from werkzeug.utils import secure_filename
        ALLOWED_EXTENSIONS = ('zip', 'gz', 'tgz', 'xz', 'bz2')

        file = request.files['file']
        logger.info(file)
        if file.filename == '':
            return jsonify(
                {
                    "status": "failed",
                    "message": "No file selected for uploading"
                }), 400

        if file and file.filename.rsplit('.', 1)[
            1].lower() in ALLOWED_EXTENSIONS:
            models_path = 'models'
            filename = secure_filename(file.filename)
            logger.info(filename)
            os.makedirs(models_path, exist_ok=True)
           


            file.save(os.path.join(models_path, filename))
            logger.info(
                '********Model is uploaded successfully********')

            # extracting model zip file and updating model config
            mp.extract_file(models_path)

            return jsonify(
                {
                    "status": "success",
                    "message": "Model is uploaded successfully"
                })

        else:
            return jsonify(
                {
                    "status": "failed",
                    "message": "Uploaded file format is not supported"
                }), 400

    except Exception as e:
        logger.exception(f'error at uploading zip file {e}')
        return jsonify(
            {
                "status": "failed",
                "message": "Error at uploading zip file"
            }), 400


@app.route('/api/model', defaults={'id': None}, methods=['GET'])
@app.route('/api/model/<id>', methods=['GET', 'DELETE'])
def model(id):
    """
        Perform operations based on method requested

        Parameters
        ------
            id: str
                Model id/ dir name of model
        Returns
        ------
            Models info based on method requested
        Exceptions
        ------
            Raises exception if fails to perform operation
    """
    if flask.request.method == 'GET':

        try:
            response = mp.get_model(id)

        except Exception as e:
            logger.exception(f"error at fetching model(s) info {e}")
            response = str(e)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching model(s) info: {response}"
                }), 400
        else:
            return jsonify(response)

    elif flask.request.method == 'DELETE':

        try:
            message, status = mp.remove_model(id)
        except Exception as e:
            logger.exception(f"Error at performing retraining: {e}")
            status = 'failed'
            message = str(e)

        if status == 'failed':
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing model: {message}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": message,
                })




@app.route('/api/prediction', methods=['POST'])
def perform_prediction():
    """
        Get the JSON data , filepath and file_encoding = 'utf-8'

        Parameters
        ------
            No params are required
        Returns
        ------
            prediction data in json format
        Exceptions
        ------
            Raises exception if fails to compute prediction and
            returns error message
        """
    
    prediction_data = None
    if request.args.get('result', "other") != "file_upload":
        prediction_data = request.get_json()
    logger.info('Prediction data: {}'.format(prediction_data))
    

    prediction_obj = dict(
        project=request.args.get('projectType'),
        id=request.args.get('id'),
        encoding_codec=request.args.get('fileEncoding'),
        
    )
    
    id = request.args.get('id')
    if request.args.get('projectType') in ['timeseries', 'clustering']:
        prediction_obj['resultType'] = request.args.get('result')

    else:
        if 'computeDrift' in request.args:
            prediction_obj['computeDrift'] = request.args.get(
                'computeDrift')
            prediction_obj['driftReportName'] = request.args.get(
                'driftReportName')
    try:

        response = ps_util.Utils(logger, prediction_obj).get_prediction(
                prediction_data)

        if request.args.get('result')=="file_upload":

            timestamp = str(int(round(datetime.now().timestamp())))
            data_frame = pd.DataFrame(response)
            csv_name = "predicted_data"+"_"+timestamp+".csv"
            models_path = 'models'
            path = os.path.join(models_path,id,csv_name)
            data_frame.to_csv(path.replace(":", "_"),index=False)
          
            return jsonify({
                "status": "success",
                "message": "Prediction has been completed",
                "results": response[:10],
                "path":path})

        else:
            return jsonify({
                "status": "success",
                "message": "Prediction has been completed",
                "results": response
            })

    except Exception as e:
        logger.exception(f"Error at performing prediction: {e}")
        response = str(e)

    if isinstance(response, str):
        return jsonify(
            {
                "status": "failed",
                "message": f"Error at performing prediction: {response}"
            }), 400

   
@app.route('/api/prediction/download', methods=['GET'])
def download_prediction():
    """
        Get the JSON data , filepath

        Parameters
        ------
            No params are required
        Returns
        ------
            Download prediction data in csv file
        Exceptions
        ------
            Raises exception if fails to download the file and
            returns error message
        """

    path = request.args.get('path')
    path.replace(":","_")

    try:

        return send_file(path, as_attachment = True)

    except Exception as e:

        logger.exception(f"Error at Downloading prediction file: {e}")
        response = str(e)
        return jsonify({
                        "status": "failed",
                        "message": f"Error at Downloading "\
                                   f" prediction file: {response}"
                        }),400


# #Retraining API
@app.route('/api/retraining', methods=['POST'])
def perform_retraining():
    """
        performs retraining on data provided on api

        Parameters:
        ------
            No params are required
        Returns
        ------
            model performance metrics

        Exceptions
        ------
            Raises exception if fails to retrain existing model
    """

    request_obj = None
    if request.args.get('source', "other").lower() != "file":
        request_obj = request.get_json()
    logger.info('Retraining Data: {}'.format(request_obj))

    toolkit_obj = dict(
        project=request.args.get('projectType'),
        id=request.args.get('id'),
        encoding_codec=request.args.get('fileEncoding')
    )

    retraining_obj = dict(
        # modelPath=request.args.get('id'),
        # projectType=request.args.get('projectType'),
        mergeData=eval(request.args.get('mergeData').capitalize()),
        overwriteModel=eval(request.args.get('overwriteModel').capitalize()),
        source=request.args.get('source'),
        retrainType=request.args.get('retrainType')
    )

    if request.args.get('source') == 'sql':

        if 'configId' in request_obj:
            retraining_obj['configId'] = request_obj['configId']
        if 'sqlQuery' in request_obj:
            retraining_obj['sqlQuery'] = request_obj['sqlQuery']
        if request.args.get('jobId'):
            retraining_obj['jobId'] = request.args.get('jobId')

            if request.args.get('alertId'):
                retraining_obj['alertId'] = request.args.get('alertId')
                retraining_obj['alertType'] = request.args.get('alertType')

    class_obj = ps_retrain.Retrain(logger, toolkit_obj, retraining_obj)

    try:
        response = class_obj.retrain_model(request_obj)
    except Exception as e:
        logger.exception(f"Error at performing retraining: {e}")
        response = str(e)

    if isinstance(response, str):
        return jsonify(
            {
                "status": "failed",
                "message": f"Error at performing retraining: {response}"
            }), 400
    else:
        return jsonify(
            {
                "status": "success",
                "message": "Retraining has been completed",
                "results": response[3]  # metrics
            })


@app.route('/api/prediction/stats', methods=['GET'])
def compute_stats():
    """
    Get the JSON data , filepath and file_encoding = 'utf-8'

    Parameters
    ------
        No params are required
    Returns
    ------
    metrics with different counts i.e for days , week and month along with
    the graph data , status and message

    Exceptions
    ------
        Raises exception if fails to create metrics
    """

    stats_obj = dict(
        project=request.args.get('projectType'),
        id=request.args.get('id'),
        encoding_codec=request.args.get('fileEncoding', None)
    )
    try:
        response = ps_util.Utils(logger, stats_obj).get_stats()
    except Exception as e:
        logger.exception(f"Error at fetching stats: {e}")
        response = str(e)

    if isinstance(response, str):
        return jsonify(
            {
                "status": "failed",
                "message": f"Error at fetching stats: {response}"
            }), 400
    else:
        return jsonify(
            {
                "status": "success",
                "message": "Prediction stats calculated successfully",
                "results": response
            })


@app.route('/api/schedule', defaults={'jobId': None}, methods=['GET',
                                                               'POST'])
@app.route('/api/schedule/<jobId>', methods=['GET', 'DELETE', 'PUT'])
def schedule_job(jobId):
    """
        function be used in list, create, update, remove the jobs

        Parameters
        ------
            jobId: str
                id of a job
        Returns
        ------
            response : dictionary with below keys
                job: Job Scheduler
                    scheduled job id
                status: str
                    active, pause and remove status of a job

        Exceptions
        ------
            Raises exception if fails to schedule the job
    """

    scheduler_obj = scheduler.JobScheduler(logger, job_config)

    if flask.request.method == 'GET':
        response = scheduler_obj.get_scheduled_job(job_id=jobId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching job(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"Job(s) retrieved successfully" if len(
                        response) > 0 else 'No job(s) found',
                    "results": response
                })
    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        function_args = dict(job_id=str(ObjectId()))
        task_executer = task.Task(logger)

        response = scheduler_obj.schedule_job(task_executer.execute_task,
                                              function_args,
                                              request_obj,
                                              sched=sched)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at scheduling job: {response}"
                }), 400
        else:
            job_config[response['jobId']] = {'job': response['job'],
                                             'jobId': response['jobId'],
                                             'jobStatus': response['jobStatus']
                                             }

            response.pop('job')
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['jobName']} job has been "
                    f"scheduled",
                    "results": response
                })
    elif flask.request.method == 'PUT':
        request_obj = request.get_json()

        if jobId in job_config:

            if 'jobStatus' in request_obj:
                if request_obj['jobStatus'] == 'active':
                    response = scheduler_obj.resume_job(jobId)

                    job_config[response['jobId']] = response

                    if isinstance(response, str):
                        return jsonify(
                            {
                                "status": "failed",
                                "message": f"Error at removing job: {response}"
                            }), 400
                    else:
                        return jsonify(
                            {
                                "status": "success",
                                "message": "Job has been resumed",
                                "results": dict(jobId=response['jobId'],
                                                jobStatus=response['jobStatus']
                                                )
                            })

                elif request_obj['jobStatus'] == 'inactive':
                    response = scheduler_obj.pause_job(jobId)

                    job_config[response['jobId']] = response

                    if isinstance(response, str):
                        return jsonify(
                            {
                                "status": "failed",
                                "message": f"Error at removing job: {response}"
                            }), 400
                    else:
                        return jsonify(
                            {
                                "status": "success",
                                "message": "Job has been paused",
                                "results": dict(jobId=response['jobId'],
                                                jobStatus=response[
                                                    'jobStatus'])
                            })
            else:
                # edit existing job
                response = scheduler_obj.update_job(jobId, request_obj)

                job_config[response['jobId']] = response

                if isinstance(response, str):
                    return jsonify(
                        {
                            "status": "failed",
                            "message": f"Error at updating job: {response}"
                        }), 400
                else:
                    return jsonify(
                        {
                            "status": "success",
                            "message": "Job has been updated",
                            "results": dict(jobId=response['jobId'],
                                            jobStatus=response['jobStatus'])
                        })
        else:
            # modify existing job
            return jsonify(
                {
                    "status": "failed",
                    "message": "No job(s) to modify"
                }), 400
    else:
        if jobId in job_config:
            # flask.request.method == 'DELETE'
            response = scheduler_obj.remove_job(jobId)

            del (job_config[response['jobId']])

            if isinstance(response, str):
                return jsonify(
                    {
                        "status": "failed",
                        "message": f"Error at removing job: {response}"
                    }), 400
            else:
                return jsonify(
                    {
                        "status": "success",
                        "message": "Job has been removed",
                        "results": dict(jobId=response['jobId'],
                                        jobStatus=response['jobStatus'])
                    })
        else:
            # modify existing job
            return jsonify(
                {
                    "status": "failed",
                    "message": "No job(s) to delete"
                }), 400


@app.route('/api/task/<taskId>', methods=['GET',
                                          'DELETE'])
def scheduler_task(taskId):
    """
        function be used in get and remove task

        Parameters
        ------
            jobId: str
                id of scheduler job
        Returns
        ------
            response : list
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to get task
    """

    if flask.request.method == 'GET':
        response = task.Task(logger).get_task(taskId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching task(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"task(s) retrieved successfully" if len(
                        response) > 0 else 'No task(s) found',
                    "results": response
                })

    else:
        # remove task
        response = task.Task(logger).remove_task(taskId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing task: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Task has been removed",
                    "results": response
                })


@app.route('/api/alerts', defaults={'alertId': None}, methods=['GET',
                                                               'POST'])
@app.route('/api/alerts/<alertId>', methods=['GET', 'DELETE', 'PUT'])
def alert_system(alertId):
    """
        function be used in list, create, update, remove the alert

        Parameters
        ------
            alertId: str
                id of an alert
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to send alert
    """

    class_obj = alert.Alert(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_alert(alertId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching alert(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"Alert(s) retrieved successfully" if len(
                        response) > 0 else 'No alert(s) found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_alert(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating alert: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['alertName']} alert has been "
                    f"created",
                    "results": response
                })

    elif flask.request.method == 'PUT':
        request_obj = request.get_json()
        response = class_obj.update_alert(alertId, request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at updating alert: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Alert has been updated",
                    "results": response
                })

    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_alert(alertId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing alert: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Alert has been removed",
                    "results": response
                })


@app.route('/api/drift_config', defaults={'configId': None}, methods=['GET',
                                                                      'POST'])
@app.route('/api/drift_config/<configId>', methods=['GET', 'DELETE', 'PUT'])
def drift_config(configId):
    """
        function be used in list, create, update, remove the drift config

        Parameters
        ------
            configId: str
                id of a drift
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to create config
    """

    class_obj = ps_drift.DriftConfig(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_drift_config(configId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching drift(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"Drift(s) config retrieved successfully" if
                    len(
                        response) > 0 else 'No drift(s) config found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_drift_config(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating drift config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['configName']} drift config has "
                    f"been created",
                    "results": response
                })

    elif flask.request.method == 'PUT':
        request_obj = request.get_json()
        response = class_obj.update_drift_config(configId, request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at updating drift config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Drift config has been updated",
                    "results": response
                })

    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_drift_config(configId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing drift config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Drift config has been removed",
                    "results": response
                })


@app.route('/api/drift_report', defaults={'reportId': None}, methods=['GET',
                                                                      'POST'])
@app.route('/api/drift_report/<reportId>', methods=['GET', 'DELETE'])
def drift_report(reportId):
    """
        function be used in list, create, update, remove the drift config

        Parameters
        ------
            reportId: str
                id of a drift report
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to create config
    """

    class_obj = ps_drift.ComputeDrift(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_drift_report(reportId,
                                              input_feature=request.args.get(
                                                  'inputFeature'))

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching drift(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"Drift report retrieved successfully" if
                    len(
                        response) > 0 else 'No drift(s) config found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_drift_report(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating drift report: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['driftReportName']} drift "
                    f"report has been created",
                    "results": response
                })
    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_drift_report(reportId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing drift report: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Drift report has been removed",
                    "results": response
                })


@app.route('/api/db_connection', defaults={'connectionId': None},
           methods=['GET',
                    'POST'])
@app.route('/api/db_connection/<connectionId>', methods=['GET', 'DELETE',
                                                         'PUT'])
def db_connection(connectionId):
    """
        function be used in list, create, update, remove the db connection

        Parameters
        ------
            connectionId: str
                id of a connection
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to create connection
    """

    class_obj = ps_sql.Connection(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_db_connection(connectionId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching DB connection(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"DB connection retrieved successfully" if len(
                        response) > 0 else 'No DB connection(s) found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_db_connection(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating db connection: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['connectionName']} has"
                    f" been created",
                    "results": response
                })

    elif flask.request.method == 'PUT':
        request_obj = request.get_json()
        response = class_obj.update_db_connection(connectionId, request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at updating DB connection: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "DB connection has been updated",
                    "results": response
                })

    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_db_connection(connectionId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing DB connection: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "DB connection has been removed",
                    "results": response
                })


@app.route('/api/sql_config', defaults={'configId': None},
           methods=['GET',
                    'POST'])
@app.route('/api/sql_config/<configId>', methods=['GET', 'DELETE',
                                                  'PUT'])
def sql_config(configId):
    """
        function be used in list, create, update, remove the sql config

        Parameters
        ------
            configId: str
                id of a connection
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to create sql config
    """

    class_obj = ps_sql.SqlConfig(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_sql_config(configId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching sql config(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"SQL config retrieved successfully" if len(
                        response) > 0 else 'No SQL config(s) found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_sql_config(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating sql config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['configName']} has"
                    f" been created",
                    "results": response
                })

    elif flask.request.method == 'PUT':
        request_obj = request.get_json()
        response = class_obj.update_sql_config(configId, request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at updating sql config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "SQL config has been updated",
                    "results": response
                })

    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_sql_config(configId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing sql config: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "SQL config has been removed",
                    "results": response
                })


@app.route('/api/monitor', defaults={'monitorId': None}, methods=[
    'GET',
    'POST'])
@app.route('/api/monitor/<monitorId>',
           methods=['GET', 'DELETE', 'PUT'])
def monitor_setting(monitorId):
    """
        function be used in list, create, update, remove the monitor setting

        Parameters
        ------
            monitorId: str
                id of a monitor
        Returns
        ------
            response : dict
                as per requested methods

        Exceptions
        ------
            Raises exception if fails to create monitor setting
    """

    class_obj = monitor.Monitor(logger)

    if flask.request.method == 'GET':
        response = class_obj.get_monitor(monitorId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at fetching monitor setting(s): {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"Monitor setting(s) retrieved successfully" if
                    len(
                        response) > 0 else 'No Monitor setting(s) found',
                    "results": response
                })

    elif flask.request.method == 'POST':
        request_obj = request.get_json()
        response = class_obj.create_monitor(request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at creating monitor setting: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": f"{request_obj['monitorName']} monitor setting "
                    f"has been created",
                    "results": response
                })

    elif flask.request.method == 'PUT':
        request_obj = request.get_json()
        response = class_obj.update_monitor(monitorId, request_obj)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at updating monitor setting: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Monitor setting(s) has been updated",
                    "results": response
                })

    else:
        # flask.request.method == 'DELETE'
        response = class_obj.remove_monitor(monitorId)

        if isinstance(response, str):
            return jsonify(
                {
                    "status": "failed",
                    "message": f"Error at removing monitor setting: {response}"
                }), 400
        else:
            return jsonify(
                {
                    "status": "success",
                    "message": "Monitor setting has been removed",
                    "results": response
                })


@app.route('/api/test_connection', methods=['POST'])
def test_connection():
    """
        to test the sql db connection is valid or not

        Parameters
        ------
            no params
        Returns
        ------
            response : dict
                as per success and error response

        Exceptions
        ------
            Raises exception if fails to test connection
    """

    data_from_ui = request.get_json()
    logger.info(f'Connection details {data_from_ui}')

    from predictsense import sql_transformer
    message, status = sql_transformer.test_connection(data_from_ui)

    response = jsonify(
        {
            "status": status,
            "message": message
        })

    return response if status == 'success' else response, 400


if __name__ == '__main__':
    # setting default toolkit host and port
    default_host = '0.0.0.0'
    default_port = 5005

    # fetching host and port from env var if default is not set
    host = os.environ.get('TOOLKIT_HOSTNAME', default_host)
    port = os.environ.get('TOOLKIT_PORT', default_port)
    logger.info(
        f'********Toolkit running on Host={host} and Port={port}********')
    job_scheduler = scheduler.JobScheduler(logger, job_config)
    sched = job_scheduler.initialize_scheduler()
    job_config = job_scheduler.restore_scheduled_job(scheduler=sched)

    app.run(host=host, port=port, debug=False)
